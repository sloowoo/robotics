/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Clawbot Template (4-motor Drivetrain, No Gyro)            */
/*                                                                            */
/*    Name:                                                                   */
/*    Date:                                                                   */
/*    Class:                                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, 11, 20   
// ArmMotor             motor         3               
// ClawMotor            motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"


using namespace vex;


// Buttons Used: L1 , L2, R1, R2, Button_A, Button_ X

   


/*
void whenC1XPressed(){
 
}
*/

void whenC1L1Pressed() {
  GodC.spin(forward);
  waitUntil(!C1.ButtonR1.pressing());
  GodC.stop();
}

void whenC1L2Pressed() {
  GodC.spin(reverse);
  waitUntil(!C1.ButtonR2.pressing());
  GodC.stop();
}

void ADrive(void) {
  Drivetrain.driveFor(forward, 30, inches);
  Drivetrain.turnFor(left, 90, degrees);
  Drivetrain.driveFor(forward, 20, inches);
}

void whenC1APressed() {
  ADrive(); 
}

int main (){
  vexcodeInit();
    
  int deadband1 = 15;

    C1.ButtonA.pressed(whenC1APressed);

    

    //C1.ButtonL1.pressed(whenC1L1Pressed);
    //C1.ButtonL2.pressed(whenC1L2Pressed);
    C1.ButtonL1.pressed(whenC1L1Pressed);
    C1.ButtonL2.pressed(whenC1L2Pressed);
    GodC.setStopping(hold);
    hUp.setStopping(hold);

    //LiftF.setVelocity(60);
    //LiftF.setStopping(hold);
    //LiftB.setVelocity(60);
    //LiftB.setStopping(hold);
  
    

  while (true) {
    // Get the velocity percentage of the left motor. (Axis3 + Axis4)      
    int LeftDriveSpeed =
      C1.Axis3.position() + C1.Axis4.position();
      // Get the velocity percentage of the right motor. (Axis3 - Axis4)
    int RightDriveSpeed =
      C1.Axis3.position() - C1.Axis4.position();
    int hUpSpeed = C1.Axis2.position();
      
    if (abs(LeftDriveSpeed) < deadband1) {
      // Set the speed to zero.
      LeftDrive.setVelocity(0, percent);
    } else {
      // Set the speed to leftMotorSpeed
      LeftDrive.setVelocity(LeftDriveSpeed, percent);
    }
      
    if (abs(RightDriveSpeed) < deadband1) {
      // Set the speed to zero
      RightDrive.setVelocity(0, percent);
    } else {
      // Set the speed to rightMotorSpeed
      RightDrive.setVelocity(RightDriveSpeed, percent);
    }

  
    if (abs(hUpSpeed) < deadband1) {
      // Set the speed to zero
      hUp.setVelocity(0, percent);
      } else {
      // Ser the speed to Hook Up
      hUp.setVelocity(hUpSpeed, percent);
      }
      

    // Spin both motors in the forward direction.
    LeftDrive.spin(forward);
    RightDrive.spin(forward);
    hUp.spin(forward);
    wait(15, msec);

      

      
    
  }
}





