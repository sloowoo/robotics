#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor lFront = motor(PORT9, ratio18_1, true);         //T/F not checked
motor lBack = motor(PORT19, ratio18_1, true);         //T/F not checked
motor_group LeftDrive = motor_group(lFront, lBack);

motor rFront = motor(PORT10, ratio18_1, false);         //T/F not checked
motor rBack = motor(PORT20, ratio18_1, false);         //T/F not checked
motor_group RightDrive = motor_group(rFront, rBack);

drivetrain Drivetrain = drivetrain(LeftDrive, RightDrive, 319.19, 295, 40, mm, 1);

motor GodC = motor(PORT5, ratio18_1, false);

motor hUp = motor(PORT16, ratio18_1, true);

controller C1 = controller();


// VEXcode generated functions



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {}
 // nothing to init