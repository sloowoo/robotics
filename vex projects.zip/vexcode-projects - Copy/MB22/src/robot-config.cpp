#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor lFront = motor(PORT15, ratio18_1, false);          
motor lBack = motor(PORT20, ratio18_1, false);         
motor_group LeftDrive = motor_group(lFront, lBack);

motor rFront = motor(PORT18, ratio18_1, true);          
motor rBack = motor(PORT16, ratio18_1, true);           
motor_group RightDrive = motor_group(rFront, rBack);

motor lIn = motor(PORT14, ratio18_1, true);
motor rIn = motor(PORT13, ratio18_1, false);
motor_group Intake = motor_group(lIn, rIn);

motor Wheel = motor(PORT6, ratio18_1, false);

drivetrain Drivetrain = drivetrain(LeftDrive, RightDrive, 319.19, 295, 40, mm, 1);

controller Controller7 = controller();


/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}