/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Clawbot Template (4-motor Drivetrain, No Gyro)            */
/*                                                                            */
/*    Name:                                                                   */
/*    Date:                                                                   */
/*    Class:                                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, 11, 20   
// ArmMotor             motor         3               
// ClawMotor            motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

void whenC7R1Pressed() {
  Intake.spin(reverse);
  waitUntil(!Controller7.ButtonR1.pressing());
  Intake.stop();
}

void whenC7R2Pressed() {
  Intake.spin(forward);
  waitUntil(!Controller7.ButtonR2.pressing());
  Intake.stop();
}


void whenC7L1Pressed() {
  Wheel.spin(forward);
  waitUntil(!Controller7.ButtonL1.pressing());
  Wheel.stop();
}

void whenC7L2Pressed() {
  Wheel.spin(reverse);
  waitUntil(!Controller7.ButtonL2.pressing());
  Wheel.stop();
}



int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  int deadband = 15;   // find out how to make the dead zone <= 15 and >=-15

  Intake.setStopping(hold);
  Intake.setVelocity(60, percent);

  Wheel.setVelocity(100, percent);

  Controller7.ButtonR1.pressed(whenC7R1Pressed);
  Controller7.ButtonR2.pressed(whenC7R2Pressed);
  Controller7.ButtonL1.pressed(whenC7L1Pressed);
  Controller7.ButtonL2.pressed(whenC7L2Pressed);

  while (true) {
    // Get the velocity percentage of the left motor. (Axis3 + Axis4)
    int LeftDriveSpeed =
        Controller7.Axis3.position() + Controller7.Axis4.position();
    // Get the velocity percentage of the right motor. (Axis3 - Axis4)
    int RightDriveSpeed =
        Controller7.Axis3.position() - Controller7.Axis4.position();
  
    // Set the speed of the left motor. If the value is less than the deadband,
    // set it to zero.
    if (abs(LeftDriveSpeed) < deadband) {
      // Set the speed to zero.
      LeftDrive.setVelocity(0, percent);
    } else {
      // Set the speed to leftMotorSpeed
      LeftDrive.setVelocity(LeftDriveSpeed, percent);
    }
    // Set the speed of the right motor. If the value is less than the deadband,
    // set it to zero.
    if (abs(RightDriveSpeed) < deadband) {
      // Set the speed to zero
      RightDrive.setVelocity(0, percent);
    } else {
      // Set the speed to rightMotorSpeed
      RightDrive.setVelocity(RightDriveSpeed, percent);
    }
    // Spin both motors in the forward direction.
    LeftDrive.spin(forward);
    RightDrive.spin(forward);
    wait(1, msec);


  }
}



/*
int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Deadband stops the motors when Axis values are close to zero.
  int deadband = 15;

  Intake.setStopping(hold);
  Intake.setVelocity(60, percent);

  Controller7.ButtonR1.pressed(whenC7R1Pressed);
  Controller7.ButtonR2.pressed(whenC7R2Pressed);

  while (true) {
    // Get the velocity percentage of the left motor. (Axis3)
    int LeftDriveSpeed = Controller7.Axis3.position();
    // Get the velocity percentage of the right motor. (Axis2)
    int RightDriveSpeed = Controller7.Axis2.position();

    // Set the speed of the left motor. If the value is less than the deadband,
    // set it to zero.
    if (abs(LeftDriveSpeed) < deadband) {
      // Set the speed to zero.
      LeftDrive.setVelocity(0, percent);
    } else {
      // Set the speed to leftMotorSpeed
      LeftDrive.setVelocity(LeftDriveSpeed, percent);
    }

    // Set the speed of the right motor. If the value is less than the deadband,
    // set it to zero.
    if (abs(RightDriveSpeed) < deadband) {
      // Set the speed to zero
      RightDrive.setVelocity(0, percent);
    } else {
      // Set the speed to rightMotorSpeed
      RightDrive.setVelocity(RightDriveSpeed, percent);
    }

    // Spin both motors in the forward direction.
    LeftDrive.spin(forward);
    RightDrive.spin(forward);
    wait(1, msec);
  }
}
*/


//=====================================================================================

/*
int main(){
  Drivetrain.turnFor(90, degrees);
  Drivetrain.drive(forward);


}
*/




